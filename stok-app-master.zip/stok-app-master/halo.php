<?php
    echo 'Selamat datang di PHP';
?>