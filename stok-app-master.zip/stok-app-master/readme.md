# Langkah penggunaan travis-ci

1. Akun Github, travis-ci
2. Download composer, running, hasil composer.phar
3. file composer.json
4. running `php composer.phar install`
5. file `phpunit.xml`
6. konfigurasi file `.travis.yml`
7. buat repository project di github.com
8. kaitkan repository github di travis-ci
9. commit and push data ke github.com

