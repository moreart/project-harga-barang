<h2>Formulir Entry Data</h2>
<hr>
<form action="simpan-baru.php" method="post">
    <table>
        <tr>
            <td>KODE </td>
            <td>: <input type="text" name="kode"></td>
        </tr>
        <tr>
            <td>NAMA BARANG</td> 
            <td>: <input type="text" name="namaBarang"></td>
        </tr>
        <tr>
            <td>STOK</td>
            <td> : <input type="text" name="stok"></td>
        </tr>
    </table>
    <input type="submit" value="Simpan">
</form>